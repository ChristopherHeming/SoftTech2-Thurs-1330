# TowerOfHanoi.py

result = 1

def main():
    n = eval(input("Enter number of disks: "))
    # Find the solution recursively
    print("The moves are:")
    moveDisks(n, 'A', 'B', 'C')
    result = (result + 1)
    print("number of moves:", result)
    
# The function for finding the solution to move n disks
# from fromTower to toTower with auxTower
def moveDisks(n, fromTower, toTower, auxTower):
    if n == 1: # Stopping condition
        print("Move disk", n, "from", fromTower, "to", toTower)
    else:
        moveDisks(n - 1, fromTower, auxTower, toTower)
        print("Move disk", n, "from", fromTower, "to", toTower)
        moveDisks(n - 1, auxTower, toTower, fromTower)
        #print("number of moves:", x)

main() # Call the main function


#print("number of moves:", moves)
